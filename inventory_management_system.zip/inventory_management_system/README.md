# Inventory Management System

## Description

This Python program is an Inventory Management System based on the provided flowsheet. The system allows a user to log in, view a main menu, and complete inventory actions such as adding, updating, removing, searching, and viewing a summary of inventory items.

The program also checks stock levels after inventory changes and displays a low-stock alert when an item's quantity is below the required threshold.

## Features

- User login simulation
- Main menu display
- Add new inventory items
- Update existing inventory items
- Remove inventory items
- Search inventory by item name
- View inventory summary
- Check stock levels
- Display low-stock alerts
- Exit the system

## Files

- `inventory_system.py` - Main Python program
- `README.md` - Project documentation

## How to Run the Program

1. Make sure Python is installed on your computer.
2. Download or clone this repository.
3. Open a terminal or command prompt.
4. Navigate to the project folder.
5. Run the program using:

```bash
python inventory_system.py
```

## Program Flow

The program follows this general flow:

1. Start
2. User logs into the system
3. Main menu is displayed
4. User selects an action item
5. The selected inventory action is completed
6. Database is updated when needed
7. Stock levels are checked
8. Low-stock alerts are displayed if needed
9. User returns to the menu or exits
10. End

## Menu Options

```text
1. Add New Inventory
2. Update Existing Inventory
3. Remove Inventory
4. Search Inventory
5. Summary of Inventory
6. Exit
```

## Example Inventory Item

Each inventory item contains:

- Item name
- Quantity
- Low-stock threshold

Example:

```python
{
    "name": "Cupcake Boxes",
    "quantity": 5,
    "threshold": 10
}
```

## Notes

This version uses a Python list as a simple in-memory database. This means inventory data will reset when the program closes.

A future improvement would be saving the inventory data to a file or database so the information remains available after the program ends.

## Author

Shelese Jenkins
